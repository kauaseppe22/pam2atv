self.addEventListener('install', function(event) {
    alert("install event detected");
});